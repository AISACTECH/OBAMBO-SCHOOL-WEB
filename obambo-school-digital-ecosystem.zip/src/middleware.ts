import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

const secretKey = new TextEncoder().encode(
  process.env.AUTH_SECRET || "dev-insecure-secret-change-me-please-0000000000",
);

async function isAuthenticated(req: NextRequest, cookieName: string) {
  const token = req.cookies.get(cookieName)?.value;
  if (!token) return false;
  try {
    await jwtVerify(token, secretKey);
    return true;
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const ok = await isAuthenticated(req, "stmarks_admin_session");
    if (!ok) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
  }

  if (pathname.startsWith("/portal") && pathname !== "/portal/login" && !pathname.startsWith("/portal/forgot-password")) {
    const ok = await isAuthenticated(req, "stmarks_student_session");
    if (!ok) {
      const url = req.nextUrl.clone();
      url.pathname = "/portal/login";
      url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
  }

  if (pathname.startsWith("/alumni/dashboard")) {
    const ok = await isAuthenticated(req, "stmarks_alumni_session");
    if (!ok) {
      const url = req.nextUrl.clone();
      url.pathname = "/alumni/login";
      url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/portal/:path*", "/alumni/dashboard/:path*"],
};
