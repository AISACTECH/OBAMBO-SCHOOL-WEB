import bcrypt from "bcryptjs";
import crypto from "crypto";

export async function hashPassword(plain: string) {
  return bcrypt.hash(plain, 12);
}

export async function verifyPassword(plain: string, hash: string) {
  try {
    return await bcrypt.compare(plain, hash);
  } catch {
    return false;
  }
}

export function hashSensitive(value: string) {
  // Deterministic hash (sha256) used for exact-match lookups of sensitive
  // identifiers (e.g. birth certificate numbers) which must never be stored
  // or displayed in plain text.
  const pepper = process.env.AUTH_SECRET || "dev-insecure-secret";
  return crypto.createHash("sha256").update(`${pepper}:${value.trim().toLowerCase()}`).digest("hex");
}

export function last4(value: string) {
  const clean = value.trim();
  return clean.length <= 4 ? clean : clean.slice(-4);
}

/**
 * Very small in-memory rate limiter. This is scoped to a single server
 * instance which is acceptable for the school's traffic profile, but if the
 * app is deployed across multiple instances this should be swapped for a
 * shared store (e.g. Redis) — the function signature is designed so that
 * swap requires no call-site changes.
 */
const attempts = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, max: number, windowMs: number) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || entry.resetAt < now) {
    attempts.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, remaining: max - 1 };
  }
  if (entry.count >= max) {
    return { allowed: false, remaining: 0, retryAfterMs: entry.resetAt - now };
  }
  entry.count += 1;
  return { allowed: true, remaining: max - entry.count };
}

export function getClientIp(headers: Headers) {
  return (
    headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    headers.get("x-real-ip") ||
    "unknown"
  );
}

export function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "")
    .slice(0, 90);
}

export function sanitizeFilename(name: string) {
  const base = name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-120);
  return `${Date.now()}-${crypto.randomBytes(4).toString("hex")}-${base}`;
}

const ALLOWED_EXTENSIONS: Record<string, string[]> = {
  document: ["pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx"],
  image: ["jpg", "jpeg", "png", "webp", "gif"],
  media: ["mp3", "mp4", "wav", "webm"],
};

export function isAllowedUpload(filename: string, kind: "document" | "image" | "media") {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  return ALLOWED_EXTENSIONS[kind].includes(ext);
}

export function fileKindFromName(filename: string): "document" | "image" | "media" | "unknown" {
  const ext = filename.split(".").pop()?.toLowerCase() || "";
  for (const [kind, exts] of Object.entries(ALLOWED_EXTENSIONS)) {
    if (exts.includes(ext)) return kind as "document" | "image" | "media";
  }
  return "unknown";
}
