import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

export type SessionType = "staff" | "student" | "alumni";

export interface SessionPayload {
  id: number;
  name: string;
  role: string;
  type: SessionType;
  [key: string]: unknown;
}

const secretKey = new TextEncoder().encode(
  process.env.AUTH_SECRET || "dev-insecure-secret-change-me-please-0000000000",
);

const COOKIE_NAMES: Record<SessionType, string> = {
  staff: "stmarks_admin_session",
  student: "stmarks_student_session",
  alumni: "stmarks_alumni_session",
};

const MAX_AGE_SECONDS = 60 * 60 * 8; // 8 hours

export async function createSession(payload: SessionPayload) {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE_SECONDS}s`)
    .sign(secretKey);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAMES[payload.type], token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: MAX_AGE_SECONDS,
  });
  return token;
}

export async function getSession(type: SessionType): Promise<SessionPayload | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get(COOKIE_NAMES[type])?.value;
    if (!token) return null;
    const { payload } = await jwtVerify(token, secretKey);
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

export async function destroySession(type: SessionType) {
  const cookieStore = await cookies();
  cookieStore.delete(COOKIE_NAMES[type]);
}

export function sessionCookieName(type: SessionType) {
  return COOKIE_NAMES[type];
}
