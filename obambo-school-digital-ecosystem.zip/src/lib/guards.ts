import { NextResponse } from "next/server";
import { getSession, type SessionPayload } from "@/lib/session";
import { hasPermission, type Permission } from "@/lib/permissions";

export async function requireStudent(): Promise<SessionPayload | NextResponse> {
  const session = await getSession("student");
  if (!session || session.type !== "student") {
    return NextResponse.json({ error: "Please sign in to the student portal." }, { status: 401 });
  }
  return session;
}

export async function requireAlumni(): Promise<SessionPayload | NextResponse> {
  const session = await getSession("alumni");
  if (!session || session.type !== "alumni") {
    return NextResponse.json({ error: "Please sign in to your alumni account." }, { status: 401 });
  }
  return session;
}

export async function requireStaff(permission?: Permission): Promise<SessionPayload | NextResponse> {
  const session = await getSession("staff");
  if (!session || session.type !== "staff") {
    return NextResponse.json({ error: "Please sign in to the School Control Center." }, { status: 401 });
  }
  if (permission && !hasPermission(session.role, permission)) {
    return NextResponse.json({ error: "You do not have permission to perform this action." }, { status: 403 });
  }
  return session;
}

export function isResponse(value: unknown): value is NextResponse {
  return value instanceof NextResponse;
}
