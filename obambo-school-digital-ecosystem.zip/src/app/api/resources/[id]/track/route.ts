import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { resources } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const resourceId = Number(id);
  if (!Number.isFinite(resourceId)) return NextResponse.json({ error: "Invalid resource" }, { status: 400 });

  const body = await req.json().catch(() => ({ action: "view" }));
  const field = body.action === "download" ? resources.downloadCount : resources.viewCount;

  await db
    .update(resources)
    .set({ [body.action === "download" ? "downloadCount" : "viewCount"]: sql`${field} + 1` })
    .where(eq(resources.id, resourceId));

  return NextResponse.json({ ok: true });
}
