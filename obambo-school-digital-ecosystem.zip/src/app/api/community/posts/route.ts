import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { posts, groups } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { currentIdentity } from "@/lib/identity";
import { rateLimit } from "@/lib/security";

export async function GET(req: NextRequest) {
  const groupSlug = req.nextUrl.searchParams.get("group");
  let groupId: number | undefined;
  if (groupSlug) {
    const g = await db.select().from(groups).where(eq(groups.slug, groupSlug)).limit(1);
    groupId = g[0]?.id;
    if (!groupId) return NextResponse.json({ posts: [] });
  }
  const rows = groupId
    ? await db.select().from(posts).where(eq(posts.groupId, groupId)).orderBy(desc(posts.pinned), desc(posts.createdAt))
    : await db.select().from(posts).orderBy(desc(posts.pinned), desc(posts.createdAt)).limit(30);
  return NextResponse.json({ posts: rows.filter((p) => p.status === "published") });
}

export async function POST(req: NextRequest) {
  const identity = await currentIdentity();
  if (!identity) return NextResponse.json({ error: "Please sign in to post in the community." }, { status: 401 });

  const limit = rateLimit(`post:${identity.type}:${identity.id}`, 10, 10 * 60 * 1000);
  if (!limit.allowed) return NextResponse.json({ error: "You are posting too frequently. Please slow down." }, { status: 429 });

  const body = await req.json().catch(() => null);
  if (!body?.content || String(body.content).trim().length < 2) {
    return NextResponse.json({ error: "Post content cannot be empty." }, { status: 400 });
  }

  let groupId: number | null = null;
  if (body.groupSlug) {
    const g = await db.select().from(groups).where(eq(groups.slug, body.groupSlug)).limit(1);
    groupId = g[0]?.id ?? null;
  }

  const inserted = await db.insert(posts).values({
    groupId,
    topic: body.topic || "general",
    authorType: identity.type,
    authorId: identity.id,
    authorName: identity.name,
    title: body.title || "",
    content: String(body.content).slice(0, 4000),
    status: "published",
  }).returning();

  return NextResponse.json({ post: inserted[0] });
}
