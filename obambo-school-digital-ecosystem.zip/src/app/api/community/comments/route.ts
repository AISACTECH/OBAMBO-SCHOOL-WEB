import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { comments } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { currentIdentity } from "@/lib/identity";
import { rateLimit } from "@/lib/security";

export async function GET(req: NextRequest) {
  const postId = Number(req.nextUrl.searchParams.get("postId"));
  if (!Number.isFinite(postId)) return NextResponse.json({ comments: [] });
  const rows = await db.select().from(comments).where(eq(comments.postId, postId)).orderBy(asc(comments.createdAt));
  return NextResponse.json({ comments: rows.filter((c) => c.status === "published") });
}

export async function POST(req: NextRequest) {
  const identity = await currentIdentity();
  if (!identity) return NextResponse.json({ error: "Please sign in to comment." }, { status: 401 });

  const limit = rateLimit(`comment:${identity.type}:${identity.id}`, 20, 10 * 60 * 1000);
  if (!limit.allowed) return NextResponse.json({ error: "You are commenting too frequently." }, { status: 429 });

  const body = await req.json().catch(() => null);
  if (!body?.postId || !body?.content || String(body.content).trim().length < 1) {
    return NextResponse.json({ error: "Comment cannot be empty." }, { status: 400 });
  }

  const inserted = await db.insert(comments).values({
    postId: Number(body.postId),
    authorType: identity.type,
    authorId: identity.id,
    authorName: identity.name,
    content: String(body.content).slice(0, 1000),
  }).returning();

  return NextResponse.json({ comment: inserted[0] });
}
