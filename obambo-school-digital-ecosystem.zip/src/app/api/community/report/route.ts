import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reports } from "@/db/schema";
import { currentIdentity } from "@/lib/identity";
import { rateLimit } from "@/lib/security";

export async function POST(req: NextRequest) {
  const identity = await currentIdentity();
  const { targetType, targetId, reason, details } = await req.json().catch(() => ({}));
  if (!targetType || !targetId || !reason) return NextResponse.json({ error: "Please provide a reason for reporting." }, { status: 400 });

  const key = identity ? `${identity.type}:${identity.id}` : "anonymous";
  const limit = rateLimit(`report:${key}`, 10, 30 * 60 * 1000);
  if (!limit.allowed) return NextResponse.json({ error: "Too many reports submitted. Please try again later." }, { status: 429 });

  await db.insert(reports).values({
    targetType,
    targetId: Number(targetId),
    reason,
    details: details || "",
    reporterType: identity?.type || "alumni",
    reporterId: identity?.id,
  });

  return NextResponse.json({ ok: true });
}
