import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { polls, pollOptions, pollVotes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { currentIdentity } from "@/lib/identity";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const pollId = Number(id);
  const [poll] = await db.select().from(polls).where(eq(polls.id, pollId));
  if (!poll) return NextResponse.json({ error: "Poll not found." }, { status: 404 });
  const options = await db.select().from(pollOptions).where(eq(pollOptions.pollId, pollId));
  const votes = await db.select().from(pollVotes).where(eq(pollVotes.pollId, pollId));

  const counts = options.map((o) => ({ id: o.id, label: o.label, votes: votes.filter((v) => v.optionId === o.id).length }));
  const identity = await currentIdentity();
  const myVote = identity ? votes.find((v) => v.voterType === identity.type && v.voterId === identity.id) : null;

  return NextResponse.json({ poll, options: counts, totalVotes: votes.length, myVoteOptionId: myVote?.optionId ?? null });
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const identity = await currentIdentity();
  if (!identity) return NextResponse.json({ error: "Please sign in to vote." }, { status: 401 });

  const { id } = await params;
  const pollId = Number(id);
  const { optionId } = await req.json().catch(() => ({}));
  if (!optionId) return NextResponse.json({ error: "Please select an option." }, { status: 400 });

  const [poll] = await db.select().from(polls).where(eq(polls.id, pollId));
  if (!poll || poll.status !== "open") return NextResponse.json({ error: "This poll is closed." }, { status: 400 });
  if (poll.closesAt && new Date(poll.closesAt) < new Date()) return NextResponse.json({ error: "This poll is closed." }, { status: 400 });

  try {
    await db.insert(pollVotes).values({ pollId, optionId: Number(optionId), voterType: identity.type, voterId: identity.id });
  } catch {
    return NextResponse.json({ error: "You have already voted in this poll." }, { status: 409 });
  }

  return NextResponse.json({ ok: true });
}
