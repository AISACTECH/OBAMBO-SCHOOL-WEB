import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reactions } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { currentIdentity } from "@/lib/identity";

export async function POST(req: NextRequest) {
  const identity = await currentIdentity();
  if (!identity) return NextResponse.json({ error: "Please sign in to react." }, { status: 401 });

  const { postId, type = "like" } = await req.json().catch(() => ({}));
  if (!postId) return NextResponse.json({ error: "Missing post." }, { status: 400 });

  const existing = await db
    .select()
    .from(reactions)
    .where(and(eq(reactions.postId, Number(postId)), eq(reactions.authorType, identity.type), eq(reactions.authorId, identity.id)));

  if (existing.length > 0) {
    await db.delete(reactions).where(eq(reactions.id, existing[0].id));
    return NextResponse.json({ reacted: false });
  }

  await db.insert(reactions).values({ postId: Number(postId), authorType: identity.type, authorId: identity.id, type });
  return NextResponse.json({ reacted: true });
}
