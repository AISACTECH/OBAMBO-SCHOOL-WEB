import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { groups } from "@/db/schema";
import { slugify } from "@/lib/security";
import { requireStaff, isResponse } from "@/lib/guards";

export async function GET() {
  const rows = await db.select().from(groups);
  return NextResponse.json({ groups: rows });
}

export async function POST(req: NextRequest) {
  const session = await requireStaff("moderate_community");
  if (isResponse(session)) return session;
  const body = await req.json().catch(() => null);
  if (!body?.name) return NextResponse.json({ error: "Group name is required." }, { status: 400 });
  const slug = slugify(body.name);
  const inserted = await db.insert(groups).values({
    name: body.name,
    slug,
    description: body.description || "",
    category: body.category || "community",
    visibility: body.visibility || "school_only",
  }).returning();
  return NextResponse.json({ group: inserted[0] });
}
