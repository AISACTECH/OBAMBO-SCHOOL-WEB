import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { savedResources, resources } from "@/db/schema";
import { and, eq, inArray } from "drizzle-orm";
import { requireStudent, isResponse } from "@/lib/guards";

export async function GET() {
  const session = await requireStudent();
  if (isResponse(session)) return session;

  const saved = await db.select().from(savedResources).where(eq(savedResources.studentId, session.id));
  const ids = saved.map((s) => s.resourceId);
  const rows = ids.length ? await db.select().from(resources).where(inArray(resources.id, ids)) : [];
  return NextResponse.json({ resources: rows });
}

export async function POST(req: NextRequest) {
  const session = await requireStudent();
  if (isResponse(session)) return session;
  const { resourceId } = await req.json();
  const existing = await db.select().from(savedResources).where(and(eq(savedResources.studentId, session.id), eq(savedResources.resourceId, Number(resourceId))));
  if (existing.length === 0) {
    await db.insert(savedResources).values({ studentId: session.id, resourceId: Number(resourceId) });
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const session = await requireStudent();
  if (isResponse(session)) return session;
  const { resourceId } = await req.json();
  await db.delete(savedResources).where(and(eq(savedResources.studentId, session.id), eq(savedResources.resourceId, Number(resourceId))));
  return NextResponse.json({ ok: true });
}
