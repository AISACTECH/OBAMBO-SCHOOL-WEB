import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { hashPassword, hashSensitive, last4 } from "@/lib/security";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const session = await requireStaff("manage_users");
  if (isResponse(session)) return session;
  const rows = await db.select().from(students).orderBy(desc(students.createdAt));
  return NextResponse.json({
    students: rows.map((s) => ({ ...s, passwordHash: undefined, birthCertHash: undefined })),
  });
}

export async function POST(req: NextRequest) {
  const session = await requireStaff("manage_users");
  if (isResponse(session)) return session;

  const body = await req.json().catch(() => ({}));
  if (!body.admissionNumber || !body.name || !body.password || !body.birthCertificateNumber) {
    return NextResponse.json({ error: "Admission number, name, password and birth certificate number are required." }, { status: 400 });
  }

  const existing = await db.select().from(students).where(eq(students.admissionNumber, body.admissionNumber)).limit(1);
  if (existing.length > 0) return NextResponse.json({ error: "A student with this admission number already exists." }, { status: 409 });

  const passwordHash = await hashPassword(body.password);
  const birthCertHash = hashSensitive(body.birthCertificateNumber);

  const inserted = await db
    .insert(students)
    .values({
      admissionNumber: body.admissionNumber,
      name: body.name,
      form: body.form || "Form 1",
      stream: body.stream || "",
      passwordHash,
      birthCertHash,
      birthCertLast4: last4(body.birthCertificateNumber),
      admittedYear: body.admittedYear || new Date().getFullYear(),
    })
    .returning();

  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: "student_created", targetType: "student", targetId: inserted[0].id });

  return NextResponse.json({ student: { ...inserted[0], passwordHash: undefined, birthCertHash: undefined } });
}
