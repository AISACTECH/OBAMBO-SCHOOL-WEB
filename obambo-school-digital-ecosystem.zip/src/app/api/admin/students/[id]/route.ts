import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireStaff("manage_users");
  if (isResponse(session)) return session;
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const allowed = ["name", "form", "stream", "status", "admittedYear"];
  const patch: Record<string, unknown> = {};
  for (const key of allowed) if (key in body) patch[key] = body[key];

  await db.update(students).set(patch).where(eq(students.id, Number(id)));
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: "student_updated", targetType: "student", targetId: Number(id), details: patch });
  return NextResponse.json({ ok: true });
}
