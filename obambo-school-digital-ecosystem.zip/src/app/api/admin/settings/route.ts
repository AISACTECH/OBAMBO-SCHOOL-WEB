import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { schoolSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { invalidateSettingsCache, getSchoolSettings } from "@/lib/settings";
import { logAudit } from "@/lib/audit";

export async function GET() {
  const session = await requireStaff();
  if (isResponse(session)) return session;
  const settings = await getSchoolSettings();
  return NextResponse.json({ settings });
}

export async function PATCH(req: NextRequest) {
  const session = await requireStaff("manage_settings");
  if (isResponse(session)) return session;
  const body = await req.json().catch(() => ({}));
  const settings = await getSchoolSettings();
  delete body.id;
  await db.update(schoolSettings).set({ ...body, updatedAt: new Date() }).where(eq(schoolSettings.id, settings.id));
  invalidateSettingsCache();
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: "settings_updated", details: body });
  return NextResponse.json({ ok: true });
}
