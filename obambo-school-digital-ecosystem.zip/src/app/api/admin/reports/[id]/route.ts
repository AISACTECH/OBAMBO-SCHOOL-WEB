import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reports, posts, comments } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireStaff("moderate_community");
  if (isResponse(session)) return session;
  const { id } = await params;
  const { action, resolution } = await req.json().catch(() => ({}));

  const [report] = await db.select().from(reports).where(eq(reports.id, Number(id)));
  if (!report) return NextResponse.json({ error: "Report not found." }, { status: 404 });

  if (action === "remove_content") {
    if (report.targetType === "post") await db.update(posts).set({ status: "removed" }).where(eq(posts.id, report.targetId));
    if (report.targetType === "comment") await db.update(comments).set({ status: "removed" }).where(eq(comments.id, report.targetId));
  }
  if (action === "hide_content") {
    if (report.targetType === "post") await db.update(posts).set({ status: "hidden" }).where(eq(posts.id, report.targetId));
    if (report.targetType === "comment") await db.update(comments).set({ status: "hidden" }).where(eq(comments.id, report.targetId));
  }

  await db.update(reports).set({ status: "resolved", resolution: resolution || action, resolvedById: session.id }).where(eq(reports.id, Number(id)));
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: `moderation_${action}`, targetType: report.targetType, targetId: report.targetId });

  return NextResponse.json({ ok: true });
}
