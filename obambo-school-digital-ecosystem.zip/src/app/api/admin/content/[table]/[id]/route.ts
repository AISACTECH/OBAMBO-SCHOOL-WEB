import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  announcements,
  news,
  events,
  resources,
  leadershipProfiles,
  documents,
  media,
  developmentProjects,
  facilities,
  examinations,
  alumniStories,
  pages,
} from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";
import type { Permission } from "@/lib/permissions";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const REGISTRY: Record<string, { table: any; permission: Permission }> = {
  announcements: { table: announcements, permission: "manage_content" },
  news: { table: news, permission: "manage_content" },
  events: { table: events, permission: "manage_content" },
  resources: { table: resources, permission: "manage_content" },
  leadership: { table: leadershipProfiles, permission: "manage_content" },
  documents: { table: documents, permission: "manage_content" },
  media: { table: media, permission: "manage_content" },
  "development-projects": { table: developmentProjects, permission: "manage_content" },
  facilities: { table: facilities, permission: "manage_content" },
  examinations: { table: examinations, permission: "manage_results" },
  "alumni-stories": { table: alumniStories, permission: "manage_alumni" },
  pages: { table: pages, permission: "manage_content" },
};

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ table: string; id: string }> }) {
  const { table, id } = await params;
  const entry = REGISTRY[table];
  if (!entry) return NextResponse.json({ error: "Unknown resource." }, { status: 404 });
  const session = await requireStaff(entry.permission);
  if (isResponse(session)) return session;

  const body = await req.json().catch(() => ({}));
  delete body.id;
  const updated = await db.update(entry.table).set(body).where(eq(entry.table.id, Number(id))).returning();
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: `${table}_updated`, targetType: table, targetId: Number(id) });
  return NextResponse.json({ item: updated[0] });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ table: string; id: string }> }) {
  const { table, id } = await params;
  const entry = REGISTRY[table];
  if (!entry) return NextResponse.json({ error: "Unknown resource." }, { status: 404 });
  const session = await requireStaff(entry.permission);
  if (isResponse(session)) return session;

  await db.delete(entry.table).where(eq(entry.table.id, Number(id)));
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: `${table}_deleted`, targetType: table, targetId: Number(id) });
  return NextResponse.json({ ok: true });
}
