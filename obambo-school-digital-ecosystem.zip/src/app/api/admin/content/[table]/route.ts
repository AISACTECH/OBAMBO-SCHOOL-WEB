import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  announcements,
  news,
  events,
  resources,
  leadershipProfiles,
  documents,
  media,
  developmentProjects,
  facilities,
  examinations,
  alumniStories,
  pages,
} from "@/db/schema";
import { desc } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { slugify } from "@/lib/security";
import { logAudit } from "@/lib/audit";
import type { Permission } from "@/lib/permissions";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const REGISTRY: Record<string, { table: any; permission: Permission; hasSlug?: boolean; titleField?: string }> = {
  announcements: { table: announcements, permission: "manage_content", hasSlug: true, titleField: "title" },
  news: { table: news, permission: "manage_content", hasSlug: true, titleField: "title" },
  events: { table: events, permission: "manage_content", hasSlug: true, titleField: "title" },
  resources: { table: resources, permission: "manage_content", titleField: "title" },
  leadership: { table: leadershipProfiles, permission: "manage_content", titleField: "name" },
  documents: { table: documents, permission: "manage_content", titleField: "title" },
  media: { table: media, permission: "manage_content" },
  "development-projects": { table: developmentProjects, permission: "manage_content", titleField: "title" },
  facilities: { table: facilities, permission: "manage_content", titleField: "name" },
  examinations: { table: examinations, permission: "manage_results", titleField: "name" },
  "alumni-stories": { table: alumniStories, permission: "manage_alumni", titleField: "title" },
  pages: { table: pages, permission: "manage_content", titleField: "title" },
};

export async function GET(_req: NextRequest, { params }: { params: Promise<{ table: string }> }) {
  const { table } = await params;
  const entry = REGISTRY[table];
  if (!entry) return NextResponse.json({ error: "Unknown resource." }, { status: 404 });
  const session = await requireStaff(entry.permission);
  if (isResponse(session)) return session;

  const rows = await db.select().from(entry.table).orderBy(desc(entry.table.id));
  return NextResponse.json({ items: rows });
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ table: string }> }) {
  const { table } = await params;
  const entry = REGISTRY[table];
  if (!entry) return NextResponse.json({ error: "Unknown resource." }, { status: 404 });
  const session = await requireStaff(entry.permission);
  if (isResponse(session)) return session;

  const body = await req.json().catch(() => ({}));
  if (entry.hasSlug && !body.slug && entry.titleField && body[entry.titleField]) {
    body.slug = `${slugify(body[entry.titleField])}-${Date.now().toString(36)}`;
  }

  const inserted = (await db.insert(entry.table).values(body).returning()) as Array<{ id: number }>;
  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: `${table}_created`, targetType: table, targetId: inserted[0]?.id, details: { title: body[entry.titleField || "title"] } });
  return NextResponse.json({ item: inserted[0] });
}
