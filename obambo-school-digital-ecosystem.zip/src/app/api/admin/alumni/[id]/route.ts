import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { alumni } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";
import { notifyByIds } from "@/lib/notify";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireStaff("manage_alumni");
  if (isResponse(session)) return session;
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const allowed = ["verified", "active", "privacy"];
  const patch: Record<string, unknown> = {};
  for (const key of allowed) if (key in body) patch[key] = body[key];

  await db.update(alumni).set(patch).where(eq(alumni.id, Number(id)));

  if (patch.verified === true) {
    await notifyByIds("alumni", [Number(id)], { type: "alumni-verified", title: "Your alumni profile has been verified", body: "Welcome to the verified St Mark's alumni community!", link: "/alumni/dashboard" });
  }

  await logAudit({ actorType: "staff", actorId: session.id, actorName: session.name, action: "alumni_updated", targetType: "alumni", targetId: Number(id), details: patch });
  return NextResponse.json({ ok: true });
}
