import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireStaff("manage_content");
  if (isResponse(session)) return session;
  const { id } = await params;
  const { status } = await req.json().catch(() => ({}));
  await db.update(contactMessages).set({ status }).where(eq(contactMessages.id, Number(id)));
  return NextResponse.json({ ok: true });
}
