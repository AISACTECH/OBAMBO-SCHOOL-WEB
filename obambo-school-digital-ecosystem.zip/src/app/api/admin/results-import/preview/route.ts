import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { requireStaff, isResponse } from "@/lib/guards";
import { parseCsv, toGoogleSheetCsvUrl } from "@/lib/csv";

const EXPECTED_HEADERS = ["Admission Number", "Student Name", "Form", "Term", "Year", "Exam", "Subject", "Marks", "Grade", "Points", "Comment"];

export async function POST(req: NextRequest) {
  const session = await requireStaff("manage_results");
  if (isResponse(session)) return session;

  const { sourceUrl, csvText } = await req.json().catch(() => ({}));
  let text = csvText as string | undefined;

  if (!text) {
    if (!sourceUrl) return NextResponse.json({ error: "Please provide a Google Sheet link or CSV URL." }, { status: 400 });
    const csvUrl = toGoogleSheetCsvUrl(sourceUrl);
    try {
      const res = await fetch(csvUrl);
      if (!res.ok) throw new Error("fetch failed");
      text = await res.text();
    } catch {
      return NextResponse.json({ error: "Could not fetch the spreadsheet. Make sure it is published/shared as 'Anyone with the link can view'." }, { status: 400 });
    }
  }

  const rows = parseCsv(text);
  if (rows.length < 2) return NextResponse.json({ error: "No data rows found in the spreadsheet." }, { status: 400 });

  const header = rows[0].map((h) => h.trim());
  const dataRows = rows.slice(1);

  const colIndex = (name: string) => header.findIndex((h) => h.toLowerCase() === name.toLowerCase());
  const idx = {
    admissionNumber: colIndex("Admission Number"),
    studentName: colIndex("Student Name"),
    form: colIndex("Form"),
    term: colIndex("Term"),
    year: colIndex("Year"),
    exam: colIndex("Exam"),
    subject: colIndex("Subject"),
    marks: colIndex("Marks"),
    grade: colIndex("Grade"),
    points: colIndex("Points"),
    comment: colIndex("Comment"),
  };

  const missingColumns = Object.entries(idx).filter(([, v]) => v === -1).map(([k]) => k);
  if (missingColumns.length > 3) {
    return NextResponse.json({ error: `Spreadsheet columns do not match the expected template: ${EXPECTED_HEADERS.join(", ")}` }, { status: 400 });
  }

  const allStudents = await db.select().from(students);
  const byAdmission = new Map(allStudents.map((s) => [s.admissionNumber.toLowerCase(), s]));

  const errorReport: { row: number; field: string; value: string; error: string; suggestedFix: string }[] = [];
  const validRows: Record<string, unknown>[] = [];

  dataRows.forEach((r, i) => {
    const rowNum = i + 2; // account for header row, 1-indexed
    const admissionNumber = (r[idx.admissionNumber] || "").trim();
    const marksRaw = (r[idx.marks] || "").trim();
    const marks = Number(marksRaw);
    const grade = (r[idx.grade] || "").trim();
    const subject = (r[idx.subject] || "").trim();
    const term = (r[idx.term] || "").trim();
    const year = Number((r[idx.year] || "").trim());
    const exam = (r[idx.exam] || "").trim();
    const points = Number((r[idx.points] || "0").trim()) || 0;
    const comment = (r[idx.comment] || "").trim();

    let rowHasError = false;
    if (!admissionNumber) {
      errorReport.push({ row: rowNum, field: "Admission Number", value: admissionNumber, error: "Admission number is missing", suggestedFix: "Provide the student's admission number" });
      rowHasError = true;
    } else if (!byAdmission.has(admissionNumber.toLowerCase())) {
      errorReport.push({ row: rowNum, field: "Admission Number", value: admissionNumber, error: "Student not found", suggestedFix: "Check the admission number against school records" });
      rowHasError = true;
    }
    if (!subject) {
      errorReport.push({ row: rowNum, field: "Subject", value: subject, error: "Subject is missing", suggestedFix: "Provide a subject name" });
      rowHasError = true;
    }
    if (marksRaw === "" || Number.isNaN(marks) || marks < 0 || marks > 100) {
      errorReport.push({ row: rowNum, field: "Marks", value: marksRaw, error: "Marks must be a number between 0 and 100", suggestedFix: "Correct the marks value" });
      rowHasError = true;
    }
    if (!grade) {
      errorReport.push({ row: rowNum, field: "Grade", value: grade, error: "Grade is missing", suggestedFix: "Provide a grade (e.g. B+, C, A-)" });
      rowHasError = true;
    }
    if (!exam) {
      errorReport.push({ row: rowNum, field: "Exam", value: exam, error: "Exam name is missing", suggestedFix: "Provide an exam name, e.g. Term 2 Mid-Term" });
      rowHasError = true;
    }
    if (!term || Number.isNaN(year)) {
      errorReport.push({ row: rowNum, field: "Term/Year", value: `${term} ${r[idx.year] || ""}`, error: "Term or year is missing/invalid", suggestedFix: "Provide term (e.g. Term 1) and a numeric year" });
      rowHasError = true;
    }

    if (!rowHasError) {
      const student = byAdmission.get(admissionNumber.toLowerCase())!;
      validRows.push({
        row: rowNum,
        studentId: student.id,
        admissionNumber: student.admissionNumber,
        examName: exam,
        subject,
        marks,
        grade,
        points,
        teacherComment: comment,
        term,
        year,
      });
    }
  });

  return NextResponse.json({
    totalRows: dataRows.length,
    validRows: validRows.length,
    invalidRows: errorReport.length > 0 ? new Set(errorReport.map((e) => e.row)).size : 0,
    errorReport,
    data: validRows,
    sourceUrl: sourceUrl || "",
  });
}
