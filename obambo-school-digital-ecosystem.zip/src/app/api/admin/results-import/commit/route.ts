import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { results, resultImports } from "@/db/schema";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";
import { notifyByIds } from "@/lib/notify";

export async function POST(req: NextRequest) {
  const session = await requireStaff("manage_results");
  if (isResponse(session)) return session;

  const { data, sourceUrl, totalRows, invalidRows } = await req.json().catch(() => ({}));
  if (!Array.isArray(data) || data.length === 0) {
    return NextResponse.json({ error: "No valid rows to import." }, { status: 400 });
  }

  const importRecord = await db
    .insert(resultImports)
    .values({
      source: "google_sheet_csv",
      sourceUrl: sourceUrl || "",
      importedByName: session.name,
      totalRows: totalRows || data.length,
      validRows: data.length,
      invalidRows: invalidRows || 0,
      status: "published",
    })
    .returning();

  const importId = importRecord[0].id;

  await db.insert(results).values(
    data.map((row: Record<string, unknown>) => ({
      studentId: row.studentId as number,
      admissionNumber: row.admissionNumber as string,
      examName: row.examName as string,
      subject: row.subject as string,
      marks: row.marks as number,
      grade: row.grade as string,
      points: (row.points as number) || 0,
      teacherComment: (row.teacherComment as string) || "",
      term: row.term as string,
      year: row.year as number,
      importId,
    })),
  );

  const studentIds = Array.from(new Set(data.map((r: Record<string, unknown>) => r.studentId as number)));
  await notifyByIds("student", studentIds, {
    type: "results-released",
    title: "New examination results are available",
    body: "Your latest examination results have been published. Sign in to the student portal to view them.",
    link: "/portal/results",
  });

  await logAudit({
    actorType: "staff",
    actorId: session.id,
    actorName: session.name,
    action: "results_imported",
    targetType: "result_import",
    targetId: importId,
    details: { rows: data.length, sourceUrl },
  });

  return NextResponse.json({ ok: true, importId, imported: data.length });
}
