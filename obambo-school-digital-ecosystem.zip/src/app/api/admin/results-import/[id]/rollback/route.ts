import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { results, resultImports } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireStaff, isResponse } from "@/lib/guards";
import { logAudit } from "@/lib/audit";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await requireStaff("manage_results");
  if (isResponse(session)) return session;

  const { id } = await params;
  const importId = Number(id);

  const deleted = await db.delete(results).where(eq(results.importId, importId)).returning();
  await db.update(resultImports).set({ rolledBack: true, status: "rolled_back" }).where(eq(resultImports.id, importId));

  await logAudit({
    actorType: "staff",
    actorId: session.id,
    actorName: session.name,
    action: "results_import_rolled_back",
    targetType: "result_import",
    targetId: importId,
    details: { recordsRemoved: deleted.length },
  });

  return NextResponse.json({ ok: true, recordsRemoved: deleted.length });
}
