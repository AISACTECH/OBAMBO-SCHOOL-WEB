import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { alumni } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAlumni, isResponse } from "@/lib/guards";

const schema = z.object({
  graduationYear: z.coerce.number().int().min(1970).max(new Date().getFullYear()).optional(),
  profession: z.string().max(120).optional(),
  industry: z.string().max(120).optional(),
  location: z.string().max(120).optional(),
  bio: z.string().max(2000).optional(),
  linkedin: z.string().max(200).optional(),
  website: z.string().max(200).optional(),
  skills: z.array(z.string()).optional(),
  achievements: z.string().max(2000).optional(),
  mentorshipAvailable: z.boolean().optional(),
  mentorTypes: z.array(z.string()).optional(),
  privacy: z.enum(["public", "alumni_only", "private"]).optional(),
});

export async function GET() {
  const session = await requireAlumni();
  if (isResponse(session)) return session;
  const rows = await db.select().from(alumni).where(eq(alumni.id, session.id)).limit(1);
  const record = rows[0];
  if (!record) return NextResponse.json({ error: "Not found" }, { status: 404 });
  const safe = { ...record, passwordHash: undefined };
  return NextResponse.json({ profile: safe });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAlumni();
  if (isResponse(session)) return session;
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Please check your profile details." }, { status: 400 });
  await db.update(alumni).set(parsed.data).where(eq(alumni.id, session.id));
  return NextResponse.json({ ok: true });
}
